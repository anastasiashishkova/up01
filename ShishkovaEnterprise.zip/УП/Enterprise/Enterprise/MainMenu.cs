﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enterprise
{
    public partial class MainMenu : Form
    {
        DataBase dataBase = new DataBase();

        private int id;
        private string name, job, login;

        private void label6_Click(object sender, EventArgs e)
        {
            DB_Interface dB_Interface = new DB_Interface();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            DB_Interface dB_Interface = new DB_Interface();
            this.Hide();
            dB_Interface.ShowDialog();
            this.Show();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            LoginHistory his = new LoginHistory();
            this.Hide();
            his.ShowDialog();
            this.Show();
        }

        public MainMenu(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {
            string query = $"select login, full_name, job_title, photo from Employees where ID_empl = '{id}'";
            SqlCommand command = new SqlCommand(query, dataBase.getConnection());
            dataBase.openConnection();
            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    if (!reader.IsDBNull(reader.GetOrdinal("photo")))
                    {
                        var imageData = (byte[])reader["photo"];
                        using (var memoryStream = new MemoryStream(imageData))
                        {
                            pictureBox1.BackgroundImage = Image.FromStream(memoryStream);
                        }
                    }
                    else
                    {
                        pictureBox1.BackgroundImage = Properties.Resources.Unknown_person; 
                    }
                    name = reader["full_name"].ToString();
                    job = reader["job_title"].ToString();
                    login = reader["login"].ToString();
                }
            }
            label1.Text = login;
            label2.Text = name;
            label3.Text = job;
        }

    }
}
