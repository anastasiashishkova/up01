﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enterprise
{
    public partial class AddNote : Form
    {
        DataBase dataBase = new DataBase();

        public AddNote()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var login = textBox1.Text;
            var password = textBox2.Text;
            var full = textBox3.Text;
            var title = textBox4.Text;
            var department = textBox5.Text;
            var salary = Convert.ToDecimal(textBox6.Text);
            var bonus = Convert.ToDecimal(textBox7.Text);

            string query = $"insert into Employees (login, password, full_name, job_title, department, salary, bonus, photo) values" +
                $"('{login}', '{password}', '{full}', '{title}', '{department}', '{salary}', '{bonus}', @image)";

            SqlCommand command = new SqlCommand(query, dataBase.getConnection());

            if (pictureBox1.BackgroundImage != null)
            {
                var image = new Bitmap(pictureBox1.BackgroundImage);
                using (var memoryStream = new MemoryStream())
                {
                    image.Save(memoryStream, ImageFormat.Jpeg);
                    memoryStream.Position = 0;

                    var sqlParameter = new SqlParameter("@image", SqlDbType.VarBinary, (int)memoryStream.Length)
                    {
                        Value = memoryStream.ToArray()
                    };
                    command.Parameters.Add(sqlParameter);
                }
                dataBase.openConnection();
                command.ExecuteNonQuery();
            }
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.BackgroundImage = Image.FromFile(openFileDialog.FileName);
                }
            }
        }
    }
}
