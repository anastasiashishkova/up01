﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enterprise
{
    public partial class DB_Interface : Form
    {
        DataBase dataBase = new DataBase();

        int selectedRow;


        private void CreateColumns()
        {
            dataGridView1.Columns.Add("ID_empl", "ID");
            dataGridView1.Columns.Add("login", "Логин");
            dataGridView1.Columns.Add("password", "Пароль");
            dataGridView1.Columns.Add("full_name", "ФИ");
            dataGridView1.Columns.Add("job_title", "Должность");
            dataGridView1.Columns.Add("department", "Отдел");
            dataGridView1.Columns.Add("salary", "Оклад");
            dataGridView1.Columns.Add("bonus", "Премия");
        }

        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetString(4), record.GetString(5), record.GetDecimal(6), record.GetDecimal(7));
        }

        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();

            string query = $"select * from Employees";
            SqlCommand command = new SqlCommand(query, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            query = $"select count(*) from Employees";
            command = new SqlCommand(query, dataBase.getConnection());
            dataBase.openConnection();
            int allNotes = Convert.ToInt32(command.ExecuteScalar());
            int currNotes = dataGridView1.Rows.Count;
            label1.Text = "Записей: " + currNotes + " из " + allNotes;
            dataBase.closeConnection();
        }

        public DB_Interface()
        {
            InitializeComponent();
        }

        private void Employees_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridView1);
        }

        //главная страница
        private void label4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;
        }

        //добавить запись
        private void button1_Click(object sender, EventArgs e)
        {
            AddNote add = new AddNote();
            add.ShowDialog();
        }

        private void Search(DataGridView dgv)
        {
            dgv.Rows.Clear();
            int temp = Convert.ToInt32(textBox1.Text);
            string search = $"select * from Employees where ID_empl = '{temp}'";
            SqlCommand command = new SqlCommand(search, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            dataBase.closeConnection();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = $"select count(*) from Employees";
            SqlCommand command = new SqlCommand(query, dataBase.getConnection());
            dataBase.openConnection();
            int allNotes = Convert.ToInt32(command.ExecuteScalar());
            Search(dataGridView1);
            int currNotes = dataGridView1.Rows.Count;
            label1.Text = "Записей: " + currNotes + " из " + allNotes;
            dataBase.closeConnection();
        }

        //обновить
        private void button5_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridView1);
        }

        //редактирование
        private void button2_Click(object sender, EventArgs e)
        {
            var id = Convert.ToInt32(dataGridView1.Rows[selectedRow].Cells[0].Value);
            ChangeNote chNote = new ChangeNote(id);
            chNote.ShowDialog();
        }

        private void Delete()
        {
            dataBase.openConnection();
            var id = Convert.ToInt32(dataGridView1.Rows[selectedRow].Cells[0].Value);
            string query = $"delete from Employees where ID_empl = '{id}'";
            SqlCommand com = new SqlCommand(query, dataBase.getConnection());
            com.ExecuteNonQuery();
            dataBase.closeConnection();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Delete();
            RefreshDataGrid(dataGridView1);
        }

    }
}
