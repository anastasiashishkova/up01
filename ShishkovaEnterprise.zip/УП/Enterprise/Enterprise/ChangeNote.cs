﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enterprise
{
    public partial class ChangeNote : Form
    {
        DataBase dataBase = new DataBase();
        private int id;
        public ChangeNote(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataBase.openConnection();
            var login = textBox1.Text;
            var password = textBox2.Text;
            var full = textBox3.Text;
            var title = textBox4.Text;
            var department = textBox5.Text;
            var salary = Convert.ToDecimal(textBox6.Text);
            var bonus = Convert.ToDecimal(textBox7.Text);

            string query = $"update Employees set login = '{login}', password = '{password}', full_name = '{full}', job_title = '{title}', department = '{department}', " +
                $"salary = '{salary}', photo = @image, bonus = '{bonus}' where ID_empl = '{id}'";

            SqlCommand command = new SqlCommand(query, dataBase.getConnection());

            if (pictureBox1.BackgroundImage != null)
            {
                var image = new Bitmap(pictureBox1.BackgroundImage);
                using (var memoryStream = new MemoryStream())
                {
                    image.Save(memoryStream, ImageFormat.Jpeg);
                    memoryStream.Position = 0;

                    var sqlParameter = new SqlParameter("@image", SqlDbType.VarBinary, (int)memoryStream.Length)
                    {
                        Value = memoryStream.ToArray()
                    };
                    command.Parameters.Add(sqlParameter);
                }
                command.ExecuteNonQuery();
            }
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            using (var openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.BackgroundImage = Image.FromFile(openFileDialog.FileName);
                }
            }
        }

        private void ChangeNote_Load(object sender, EventArgs e)
        {
            dataBase.openConnection();
            string search = $"select * from Employees where ID_empl = '{id}'";
            SqlCommand com = new SqlCommand(search, dataBase.getConnection());
            SqlDataReader reader = com.ExecuteReader();
            if (reader.Read())
            {
                textBox1.Text = reader[1].ToString();
                textBox2.Text = reader[2].ToString();
                textBox3.Text = reader[3].ToString();
                textBox4.Text = reader[4].ToString();
                textBox5.Text = reader[5].ToString();
                textBox6.Text = reader[6].ToString();
                textBox7.Text = reader[7].ToString();
                if (!reader.IsDBNull(reader.GetOrdinal("photo")))
                {
                    var imageData = (byte[])reader["photo"];
                    using (var memoryStream = new MemoryStream(imageData))
                    {
                        pictureBox1.BackgroundImage = Image.FromStream(memoryStream);
                    }
                }
                else
                {
                    pictureBox1.BackgroundImage = Properties.Resources.Unknown_person;
                }
            }
            dataBase.closeConnection();
        }
    }
}
