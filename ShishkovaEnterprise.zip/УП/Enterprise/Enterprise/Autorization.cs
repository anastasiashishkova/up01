﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enterprise
{
    public partial class Autorization : Form
    {
        DataBase dataBase = new DataBase();

        private Timer timer;

        private int n; //клики по кнопке показа пароля
        private int enter; //неудачные попытки входа
        public Autorization()
        {
            InitializeComponent();
            n = 0;
            enter = 0;
            timer = new Timer();
            timer.Interval = 180000;
            timer.Tick += timer1_Tick;
        }
        //скрыть/показать пароль
        private void button2_Click(object sender, EventArgs e)
        {
            n++;
            if (n % 2 == 0)
            {
                button2.BackgroundImage = Properties.Resources.free_icon_hide_2767146;
                textBox2.UseSystemPasswordChar = true;
            }
            else
            {
                button2.BackgroundImage = Properties.Resources.free_icon_eye_158746;
                textBox2.UseSystemPasswordChar = false;
            }
        }
        //войти
        private void button1_Click(object sender, EventArgs e)
        {
            var loginUser = textBox1.Text;
            var passwordUser = textBox2.Text;

            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();

            string query = $"select ID_empl, login, password from Employees where login = '{loginUser}' and password ='{passwordUser}'";

            SqlCommand command = new SqlCommand(query, dataBase.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count == 1)
            {
                MessageBox.Show("Вы вошли!");
                query = $"insert into LoginHistory(UserLogin, LoginTime) values('{loginUser}', GETDATE())";
                command = new SqlCommand(query, dataBase.getConnection());
                dataBase.openConnection();
                command.ExecuteNonQuery();
                query = $"select ID_empl from Employees where login = '{loginUser}'";
                command = new SqlCommand(query, dataBase.getConnection());
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    int id = Convert.ToInt32(reader["ID_empl"]);
                    MainMenu menu = new MainMenu(id);
                    this.Hide();
                    menu.ShowDialog();
                    this.Show();
                }
                dataBase.closeConnection();
            }
            else
            {
                enter++;
                MessageBox.Show("Вы НЕ вошли!");

                query = $"insert into FailedLoginAttempts(UserID, FailedTime) values('{loginUser}', GETDATE())";
                command = new SqlCommand(query, dataBase.getConnection());
                dataBase.openConnection();
                command.ExecuteNonQuery();
                dataBase.closeConnection();
                if (enter == 2)
                {
                    Captcha cap = new Captcha();
                    cap.Owner = this;
                    cap.ShowDialog();
                }
                else if (enter == 3)
                {
                    MessageBox.Show("Возможность входа заблокирована на 3 минуты!");
                    button1.Enabled = false;
                    timer.Start();
                }
                else if (enter > 3)
                {
                    button1.Enabled = false;
                    MessageBox.Show("Возможность входа заблокирована!");
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            MessageBox.Show("У Вас осталась 1 попытка входа!");
            button1.Enabled = true;
        }
    }
}
