﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enterprise
{
    public partial class LoginHistory : Form
    {
        DataBase dataBase = new DataBase();

        public LoginHistory()
        {
            InitializeComponent();
        }

        private void LoginHistory_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid(dataGridView1);
        }
        private void CreateColumns()
        {
            dataGridView1.Columns.Add("ID", "Номер записи");
            dataGridView1.Columns.Add("UserLogin", "Логин");
            dataGridView1.Columns.Add("LoginTime", "Время входа");
        }
        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetDateTime(2));
        }
        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();
            string query = $"select * from LoginHistory";
            SqlCommand command = new SqlCommand(query, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            query = $"select count(*) from LoginHistory";
            command = new SqlCommand(query, dataBase.getConnection());
            dataBase.openConnection();
            int allNotes = Convert.ToInt32(command.ExecuteScalar());
            int currNotes = dataGridView1.Rows.Count;
            label1.Text = "Записей: " + currNotes + " из " + allNotes;
        }
        //фильтр
        private void button4_Click(object sender, EventArgs e)
        {

            string query = $"select count(*) from LoginHistory";
            SqlCommand command = new SqlCommand(query, dataBase.getConnection());
            dataBase.openConnection();
            int allNotes = Convert.ToInt32(command.ExecuteScalar());
            Search(dataGridView1);
            int currNotes = dataGridView1.Rows.Count;
            label1.Text = "Записей: " + currNotes + " из " + allNotes;
            dataBase.closeConnection();
        }
        private void Search(DataGridView dgv)
        {
            dgv.Rows.Clear();
            string temp = textBox1.Text;
            string search = $"select * from LoginHistory where UserLogin = '{temp}'";
            SqlCommand command = new SqlCommand(search, dataBase.getConnection());
            dataBase.openConnection();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            dataBase.closeConnection();
        }
    }
}
